package dab.domain;
import java.util.ArrayList;

public class Compte {
    private float solde;
    private ArrayList<Operation> listOperations = new ArrayList<>();

    public ArrayList<Operation> getListOperations() {
        return listOperations;
    }

    public Compte(float solde) {
        this.solde = solde;
    }
    public void retrait(float montant){
        listOperations.add(new Operation(montant, Operation.Type.RETRAIT));
        solde-=montant;
    }
    public void depot(float montant){
        listOperations.add(new Operation(montant, Operation.Type.DEPOT));
        solde += montant;
    }
    public void displaySolde(){
        System.out.println(" Votre solde est : " +solde);
    }
    public void displayOperations(){
        for (Operation op : listOperations){
            op.displayInfo();
        }
    }
}
