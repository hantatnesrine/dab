package dab.domain;

public class Operation {

    enum Type {
        DEPOT,
        RETRAIT

    }

    private float montant;
    private Type typeOperations;

    public Operation(float montant, Type typeOperations) {
        this.montant = montant;
        this.typeOperations = typeOperations;
    }

    public void displayInfo() {
        System.out.println("le type de l'operation est: "+ typeOperations );
        System.out.println("dont le montant est " + montant);

    }
}
