package dab.domain;

public class Bank {

    public enum Menu {

    }

}
