package dab;

import dab.domain.Compte;

import java.util.InputMismatchException;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Compte compte = new Compte(10000f);

        compte.retrait(100f);
        compte.displaySolde();
        compte.depot(200f);
        compte.displayOperations();

        Scanner scanner = new Scanner(System.in);
        boolean flag = true;
        do {
            System.out.println("Bonjour veuillez choisir une operation :");
            System.out.println("1 - Solde du compte");
            System.out.println("2 - Retrait");
            System.out.println("3 - Depot");
            System.out.println("4 - Liste des opérations");
            System.out.println("5 - Terminer");
            int choix;

            try {
                choix = scanner.nextInt();
            }catch (InputMismatchException e){
                choix =6;
                scanner.nextLine();
            }
            switch (choix) {
                case 1 -> compte.displaySolde();
                case 2 -> {
                    System.out.println("Quel montant voulez vous retirer ?");
                    float montant ;
                    try {
                        montant = scanner.nextFloat();
                        compte.retrait(montant);
                        compte.displaySolde();
                    }catch (InputMismatchException e){
                        System.out.println("Montant invalide");
                        scanner.nextLine();
                    }
                }
                case 3 -> {
                    System.out.println("Quel montant voulez vous déposer ?");
                    float montant = scanner.nextFloat();
                    compte.depot(montant);
                    compte.displaySolde();
                }
                case 4 -> {
                    System.out.println("Vous avez effectué :"+ compte.getListOperations().size() + " opérations");
                    compte.displayOperations();
                }
                case 5 -> {
                    flag = false;
                    System.out.println("Bye a bientot");
                }
                default -> System.out.println("Illegal operation");
            }
        } while (flag);
    }
}

