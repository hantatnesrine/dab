package com.company;

public class Auteur {
    private String name;
    private int annee;


    public Auteur(String nom, int annee) {
        this.name = name;
        this.annee = annee;
    }

}
