package com.company;

public class Disque {

    private String name;
    private Auteur author;
    private int anneeDeSorti;

    public Disque(String name, Auteur auteur, int anneeDeSorti) {
        this.name = name;
        this.author = auteur;
        this.anneeDeSorti = anneeDeSorti;
    }

    public Disque() {

    }

}


