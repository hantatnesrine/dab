package com.company;
import com.company.Disque;

public class Main {
    public static void main(String args[]){
    Disque monDisque = new Disque();

    }

}
