package exo;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        try(Scanner sc = new Scanner(System.in)){
            do{
            System.out.println("choisissez le mode de conversion : ");
            System.out.println("1 - Convertisseur Celsius - Fahrenheit");
            System.out.println("2 - Convertisseur Fahrenheit - Celsius ");
            int nb = sc.nextInt();
            if (nb == 1 || nb == 78){
                System.out.println("Temperature à convertir : ");
                int temp = sc.nextInt();
                System.out.println(convCF(temp));
            }
            else{
                System.out.println("Temperature à convertir : ");
                int temp = sc.nextInt();
                System.out.println(convFC(temp));
            }
            System.out.println("Souhaitez-vous convetir une autre temperature ? N/O");
            if (sc.nextLine().equals("o")){

            }
        }while (sc.nextInt() == 1 || sc.nextInt() == 2 && sc.nextInt()!= 80);
        }
    }

    public static float convCF(float temp){
        return temp*(9f/5) + 32;
    }

    public static float convFC(float temp){
        return (temp-32)* 5f/9;
    }
}
