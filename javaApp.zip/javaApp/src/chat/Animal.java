package chat;

public abstract class Animal {
    private  int humeur;
    private int energie;
    private int faim;

    public Animal(int humeur, int energie, int faim) {
        this.humeur = humeur;
        this.energie = energie;
        this.faim = faim;
    }

    public void dormir(){
        energie++;
        humeur++;
        faim ++;
    }
    public void jouer(){
        energie--;
        humeur++;
        faim++;
    }

    public void manger(){
        energie++;
        humeur++;
        faim--;
    }
    public void afficheEtat(){
        System.out.println("energie de l'animal : " +energie+ " son humeur : "+humeur+ " la faim: " +faim);
    }
    public abstract void parler();
}
