package chat;

public class Main {
    public static void main(String args[]){

        Chat doudou = new Chat();
        doudou.afficheEtat();
        doudou.manger();
        doudou.afficheEtat();
        doudou.jouer();
        doudou.afficheEtat();
        doudou.parler();

        Cheval cheval = new Cheval();
        cheval.afficheEtat();
        cheval.jouer();
        cheval.manger();
        cheval.afficheEtat();
        cheval.parler();
    }

}
