package chat;

public class Chat extends Animal {

    public Chat() {
        super(2, 3, 5);

    }

    @Override
    public void parler() {
        System.out.println("Miawooooooo");
    }

}
