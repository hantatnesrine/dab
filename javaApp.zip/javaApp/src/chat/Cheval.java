package chat;

public class Cheval extends Animal {
    public Cheval() {
        super(10, 5, 3);
    }

    @Override
    public void parler() {
        System.out.println("hihihihihih");
    }



}
