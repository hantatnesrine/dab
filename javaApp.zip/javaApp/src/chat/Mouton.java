package chat;

public class Mouton extends Animal{

    public Mouton() {
        super(3,6,7);
    }

    @Override
    public void parler() {
        System.out.println("bahhhhh");
    }

}
